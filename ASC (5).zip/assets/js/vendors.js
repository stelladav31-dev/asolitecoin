/**
 * Load vendors by category: buy | sell | all
 */
(function () {
  function getClient() {
    if (window._astcSupabaseClient) return window._astcSupabaseClient;
    if (window.supabase && window.SUPABASE_URL && window.SUPABASE_ANON_KEY) {
      window._astcSupabaseClient = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
      return window._astcSupabaseClient;
    }
    return null;
  }

  async function listVendors(category) {
    const client = getClient();
    if (!client) return [];
    let q = client
      .from("vendors")
      .select("*")
      .eq("is_active", true)
      .order("rank", { ascending: true });

    if (category === "buy") {
      q = q.in("category", ["buy", "both"]);
    } else if (category === "sell") {
      q = q.in("category", ["sell", "both"]);
    }
    // "all" / vendors page: no category filter

    const { data, error } = await q;
    if (error) {
      console.warn("vendors", error);
      return [];
    }
    return data || [];
  }

  function whatsappLink(num) {
    if (!num) return "#";
    var n = String(num).replace(/[^\d+]/g, "");
    if (n.charAt(0) === "+") n = n.slice(1);
    return "https://wa.me/" + n;
  }

  function renderVendorCard(v) {
    var rank = v.rank != null ? v.rank : "—";
    var quote = v.quote ? '<p class="vendor-quote">"' + escapeHtml(v.quote) + '"</p>' : "";
    var verified = v.is_verified ? '<span class="v-badge">✓ Verified</span>' : "";
    var cat = (v.category || "both").toUpperCase();
    return (
      '<div class="vendor-card">' +
        '<div class="vendor-top">' +
          '<div><div class="vendor-name">' + escapeHtml(v.name || "Vendor") + " " + verified + "</div>" +
          '<div class="vendor-meta">Rank #' + rank + " · " + cat + "</div></div>" +
        "</div>" +
        quote +
        '<a class="vendor-wa" href="' + whatsappLink(v.whatsapp) + '" target="_blank" rel="noopener">' +
          '<i class="fa-brands fa-whatsapp"></i> Chat on WhatsApp' +
        "</a>" +
      "</div>"
    );
  }

  function escapeHtml(s) {
    return String(s || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  window.ASTC_VENDORS = {
    list: listVendors,
    renderCard: renderVendorCard,
    whatsappLink: whatsappLink
  };
})();
