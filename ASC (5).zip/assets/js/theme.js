/**
 * ASOLITECOIN Theme Controller
 * Themes: dark (black + blue) | light (white + orange)
 * Persist in localStorage key: astc_theme
 */
(function () {
  const KEY = "astc_theme";

  function getTheme() {
    return localStorage.getItem(KEY) || "dark";
  }

  function applyTheme(theme) {
    const t = theme === "light" ? "light" : "dark";
    document.body.classList.toggle("light-theme", t === "light");
    document.body.setAttribute("data-theme", t);
    localStorage.setItem(KEY, t);

    // Update any theme icons on page
    document.querySelectorAll("[data-theme-icon]").forEach((el) => {
      el.className = t === "light" ? "fa-solid fa-moon" : "fa-solid fa-sun";
    });

    // Radio / select sync if present
    const radio = document.querySelector(`input[name="astc-theme"][value="${t}"]`);
    if (radio) radio.checked = true;

    window.dispatchEvent(new CustomEvent("astc:themechange", { detail: { theme: t } }));
  }

  function toggleTheme() {
    applyTheme(getTheme() === "dark" ? "light" : "dark");
  }

  // Auto-apply on load
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => applyTheme(getTheme()));
  } else {
    applyTheme(getTheme());
  }

  window.ASTC_THEME = {
    get: getTheme,
    set: applyTheme,
    toggle: toggleTheme,
    apply: applyTheme
  };
})();
