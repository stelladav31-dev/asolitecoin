/* ==========================================================================
   ASOLITECOIN (ASTC) - TRANSACTION PIN CRYPTOGRAPHIC MODULE
   ========================================================================== */

const ASTC_PIN = {
  /**
   * Hashes a 4-digit numeric PIN using SHA-256 via the Web Crypto API
   * @param {string} pin - 4-digit string (e.g., "1234")
   * @returns {Promise<string>} Hex-encoded SHA-256 hash string
   */
  async hashPin(pin) {
    if (!this.validateFormat(pin)) {
      throw new Error("Invalid PIN format. Must be exactly 4 numeric digits.");
    }

    // Add salt prefix to prevent simple lookup table rainbow attacks
    const saltedPin = `ASTC_SECURE_PIN_SALT_${pin}`;
    const encoder = new TextEncoder();
    const data = encoder.encode(saltedPin);
    
    const hashBuffer = await crypto.subtle.digest("SHA-256", data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
    
    return hashHex;
  },

  /**
   * Validates that the input is exactly 4 digits
   * @param {string} pin 
   * @returns {boolean}
   */
  validateFormat(pin) {
    return /^\d{4}$/.test(pin);
  },

  /**
   * Prompts or configures a new PIN for the user profile
   * @param {string} userId 
   * @param {string} rawPin 
   * @returns {Promise<boolean>}
   */
  async setPin(userId, rawPin) {
    if (!this.validateFormat(rawPin)) {
      throw new Error("PIN must be exactly 4 numeric digits.");
    }

    const pinHash = await this.hashPin(rawPin);

    const { data, error } = await supabaseClient
      .from("profiles")
      .update({ 
        pin_hash: pinHash,
        updated_at: new Date().toISOString()
      })
      .eq("id", userId);

    if (error) {
      console.error("Failed to update PIN:", error.message);
      throw new Error("Unable to save transaction PIN. Please try again.");
    }

    return true;
  }
};
