/**
 * ASOLITECOIN - Currency helper
 * ASTC price is stored in NGN (admin). Other currencies convert via live FX.
 */
(function () {
  const COUNTRIES = [
    { code: "NG", name: "Nigeria", currency: "NGN", symbol: "₦" },
    { code: "GH", name: "Ghana", currency: "GHS", symbol: "GH₵" },
    { code: "KE", name: "Kenya", currency: "KES", symbol: "KSh" },
    { code: "ZA", name: "South Africa", currency: "ZAR", symbol: "R" },
    { code: "US", name: "United States", currency: "USD", symbol: "$" },
    { code: "GB", name: "United Kingdom", currency: "GBP", symbol: "£" },
    { code: "EU", name: "Eurozone", currency: "EUR", symbol: "€" },
    { code: "CA", name: "Canada", currency: "CAD", symbol: "C$" },
    { code: "AU", name: "Australia", currency: "AUD", symbol: "A$" },
    { code: "IN", name: "India", currency: "INR", symbol: "₹" },
    { code: "CN", name: "China", currency: "CNY", symbol: "¥" },
    { code: "JP", name: "Japan", currency: "JPY", symbol: "¥" },
    { code: "AE", name: "United Arab Emirates", currency: "AED", symbol: "د.إ" },
    { code: "SA", name: "Saudi Arabia", currency: "SAR", symbol: "﷼" },
    { code: "EG", name: "Egypt", currency: "EGP", symbol: "E£" },
    { code: "TZ", name: "Tanzania", currency: "TZS", symbol: "TSh" },
    { code: "UG", name: "Uganda", currency: "UGX", symbol: "USh" },
    { code: "RW", name: "Rwanda", currency: "RWF", symbol: "FRw" },
    { code: "CM", name: "Cameroon", currency: "XAF", symbol: "FCFA" },
    { code: "SN", name: "Senegal", currency: "XOF", symbol: "CFA" },
    { code: "CI", name: "Côte d'Ivoire", currency: "XOF", symbol: "CFA" },
    { code: "BR", name: "Brazil", currency: "BRL", symbol: "R$" },
    { code: "MX", name: "Mexico", currency: "MXN", symbol: "Mex$" },
    { code: "TR", name: "Turkey", currency: "TRY", symbol: "₺" },
    { code: "PH", name: "Philippines", currency: "PHP", symbol: "₱" },
    { code: "PK", name: "Pakistan", currency: "PKR", symbol: "₨" },
    { code: "BD", name: "Bangladesh", currency: "BDT", symbol: "৳" },
    { code: "ID", name: "Indonesia", currency: "IDR", symbol: "Rp" },
    { code: "MY", name: "Malaysia", currency: "MYR", symbol: "RM" },
    { code: "SG", name: "Singapore", currency: "SGD", symbol: "S$" }
  ];

  // Offline fallback: 1 USD = X units of currency (approx, updated when API works)
  const FALLBACK_USD_RATES = {
    USD: 1,
    NGN: 1600,
    GHS: 15.5,
    KES: 129,
    ZAR: 18.2,
    GBP: 0.79,
    EUR: 0.92,
    CAD: 1.36,
    AUD: 1.53,
    INR: 83.5,
    CNY: 7.2,
    JPY: 149,
    AED: 3.67,
    SAR: 3.75,
    EGP: 48.5,
    TZS: 2550,
    UGX: 3700,
    RWF: 1300,
    XAF: 600,
    XOF: 600,
    BRL: 5.0,
    MXN: 17.2,
    TRY: 32.5,
    PHP: 56,
    PKR: 278,
    BDT: 110,
    IDR: 15800,
    MYR: 4.7,
    SGD: 1.34
  };

  let cachedRates = null; // 1 USD = X currency
  let ratesFetchedAt = 0;
  let astcPriceNgn = 26700;
  let astcPrevPriceNgn = 26700;

  function getClient() {
    if (window._astcSupabaseClient) return window._astcSupabaseClient;
    if (window.supabase && window.SUPABASE_URL && window.SUPABASE_ANON_KEY) {
      window._astcSupabaseClient = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
      return window._astcSupabaseClient;
    }
    return null;
  }

  async function loadAstcPrice() {
    try {
      const client = getClient();
      if (client) {
        const { data } = await client.from("platform_settings").select("key, value").in("key", [
          "astc_price_ngn", "astc_prev_price_ngn"
        ]);
        if (data) {
          data.forEach(function (row) {
            if (row.key === "astc_price_ngn") astcPriceNgn = parseFloat(row.value) || 26700;
            if (row.key === "astc_prev_price_ngn") astcPrevPriceNgn = parseFloat(row.value) || astcPriceNgn;
          });
        }
      }
    } catch (e) {
      console.warn("price load", e);
    }
    var changePct = 0;
    if (astcPrevPriceNgn > 0) {
      changePct = ((astcPriceNgn - astcPrevPriceNgn) / astcPrevPriceNgn) * 100;
    }
    return { price: astcPriceNgn, prev: astcPrevPriceNgn, changePct: changePct };
  }

  async function loadFxRates() {
    var now = Date.now();
    if (cachedRates && now - ratesFetchedAt < 30 * 60 * 1000) {
      return cachedRates;
    }

    // Start with fallbacks so every currency always has a rate
    var rates = Object.assign({}, FALLBACK_USD_RATES);

    // Try open.er-api.com (includes NGN and many African currencies)
    try {
      var res = await fetch("https://open.er-api.com/v6/latest/USD");
      if (res.ok) {
        var json = await res.json();
        if (json && json.rates) {
          Object.keys(json.rates).forEach(function (k) {
            rates[k] = json.rates[k];
          });
          ratesFetchedAt = now;
        }
      }
    } catch (e) {
      console.warn("er-api FX failed", e);
    }

    // Secondary: Frankfurter (ECB — no NGN, but good for major currencies)
    try {
      var res2 = await fetch("https://api.frankfurter.app/latest?from=USD");
      if (res2.ok) {
        var json2 = await res2.json();
        if (json2 && json2.rates) {
          Object.keys(json2.rates).forEach(function (k) {
            // Don't overwrite NGN etc if we already got them from er-api
            if (rates[k] === undefined || rates[k] === FALLBACK_USD_RATES[k]) {
              rates[k] = json2.rates[k];
            }
          });
          ratesFetchedAt = now;
        }
      }
    } catch (e2) {
      console.warn("frankfurter FX failed", e2);
    }

    rates.USD = 1;
    cachedRates = rates;
    return rates;
  }

  function symbolFor(currency) {
    var c = COUNTRIES.find(function (x) { return x.currency === currency; });
    return (c && c.symbol) || (currency + " ");
  }

  /**
   * Convert ASTC → target currency
   * 1 ASTC = priceNgn NGN (admin)
   * ngnTotal = amount * priceNgn
   * usd = ngnTotal / rates.NGN
   * target = usd * rates[currency]
   */
  async function convertAstc(astcAmount, targetCurrency) {
    var priceInfo = await loadAstcPrice();
    var rates = await loadFxRates();
    var cur = (targetCurrency || "NGN").toUpperCase().trim();
    var amount = parseFloat(astcAmount) || 0;
    var ngnTotal = amount * priceInfo.price;

    if (cur === "NGN") {
      return {
        value: ngnTotal,
        symbol: "₦",
        currency: "NGN",
        priceNgn: priceInfo.price,
        changePct: priceInfo.changePct,
        live: true
      };
    }

    var ngnPerUsd = rates.NGN || FALLBACK_USD_RATES.NGN;
    var rate = rates[cur];

    // If still missing, use fallback table
    if (rate === undefined || rate === null || rate <= 0) {
      rate = FALLBACK_USD_RATES[cur];
    }

    if (rate === undefined || rate === null || rate <= 0) {
      // Last resort: show NGN but mark it
      return {
        value: ngnTotal,
        symbol: "₦",
        currency: "NGN",
        priceNgn: priceInfo.price,
        changePct: priceInfo.changePct,
        fallback: true,
        requested: cur,
        error: "Rate unavailable for " + cur
      };
    }

    var usd = ngnTotal / ngnPerUsd;
    var value = usd * rate;

    return {
      value: value,
      symbol: symbolFor(cur),
      currency: cur,
      priceNgn: priceInfo.price,
      changePct: priceInfo.changePct,
      live: ratesFetchedAt > 0
    };
  }

  function formatMoney(value, symbol) {
    var n = parseFloat(value) || 0;
    var digits = n >= 100 ? 2 : 4;
    return (symbol || "") + n.toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: digits
    });
  }

  window.ASTC_CURRENCY = {
    COUNTRIES: COUNTRIES,
    getCountries: function () { return COUNTRIES.slice(); },
    countryByCode: function (code) {
      return COUNTRIES.find(function (c) { return c.code === code; }) || COUNTRIES[0];
    },
    loadAstcPrice: loadAstcPrice,
    loadFxRates: loadFxRates,
    convertAstc: convertAstc,
    formatMoney: formatMoney
  };
})();
