/**
 * ASOLITECOIN (ASTC) - Complete Authentication Controller
 * Fixed: accepts object OR positional args, throws on error, creates client correctly
 * Added: resetPassword + updatePassword for forgot password flow
 */

(function () {
  // Create (or reuse) a single Supabase client
  function getClient() {
    const url = window.SUPABASE_URL || (typeof SUPABASE_URL !== "undefined" ? SUPABASE_URL : null);
    const key = window.SUPABASE_ANON_KEY || (typeof SUPABASE_ANON_KEY !== "undefined" ? SUPABASE_ANON_KEY : null);

    if (!url || !key) {
      throw new Error("Supabase URL or Anon Key missing. Check assets/js/config.js");
    }

    // Prefer the global createClient from the CDN script
    if (typeof window.supabase !== "undefined" && window.supabase.createClient) {
      // Re-use if already created
      if (window._astcSupabaseClient) return window._astcSupabaseClient;
      window._astcSupabaseClient = window.supabase.createClient(url, key);
      return window._astcSupabaseClient;
    }

    throw new Error("Supabase JS library not loaded. Add the CDN script before auth.js");
  }

  const ASTC_AUTH = {
    generateWalletId() {
      const p1 = Math.floor(1000 + Math.random() * 9000);
      const p2 = Math.floor(1000 + Math.random() * 9000);
      return `ASTC-${p1}-${p2}`;
    },

    generateReferralCode(username) {
      const cleanUser = (username || "ASTC")
        .replace(/[^a-zA-Z0-9]/g, "")
        .toUpperCase()
        .slice(0, 4);
      const rand = Math.floor(100 + Math.random() * 900);
      return `${cleanUser || "ASTC"}${rand}`;
    },

    /**
     * SIGN UP
     * Accepts either an object { fullName, username, email, password, pin, referralCode }
     * or the old positional style for backward compatibility.
     */
    async signUp(arg1, username, email, password, pin, referralCode = "") {
      let fullName, cleanUsername, cleanEmail, cleanPassword, cleanPin, cleanReferral;

      // Object style (what signup.html currently uses)
      if (typeof arg1 === "object" && arg1 !== null) {
        fullName = (arg1.fullName || arg1.full_name || "").trim();
        cleanUsername = (arg1.username || "").trim().toLowerCase();
        cleanEmail = (arg1.email || "").trim().toLowerCase();
        cleanPassword = arg1.password || "";
        cleanPin = (arg1.pin || "").trim();
        cleanReferral = (arg1.referralCode || arg1.referral_code || "").trim();
      } else {
        // Positional style
        fullName = (arg1 || "").trim();
        cleanUsername = (username || "").trim().toLowerCase();
        cleanEmail = (email || "").trim().toLowerCase();
        cleanPassword = password || "";
        cleanPin = (pin || "").trim();
        cleanReferral = (referralCode || "").trim();
      }

      if (!fullName || !cleanUsername || !cleanEmail || !cleanPassword || !cleanPin) {
        throw new Error("Please fill in all required fields.");
      }
      if (!/^\d{4}$/.test(cleanPin)) {
        throw new Error("Transaction PIN must be exactly 4 numeric digits.");
      }

      const client = getClient();
      const generatedWalletId = this.generateWalletId();
      const userRefCode = this.generateReferralCode(cleanUsername);

      // Country (from object args if present)
      let countryName = "";
      let countryCode = "NG";
      let preferredCurrency = "NGN";
      if (typeof arg1 === "object" && arg1 !== null) {
        countryName = (arg1.country || "").trim();
        countryCode = (arg1.countryCode || arg1.country_code || "NG").trim();
        preferredCurrency = (arg1.preferredCurrency || arg1.preferred_currency || "NGN").trim();
      }

      // 1. Create auth user (with metadata)
      const { data: authData, error: authError } = await client.auth.signUp({
        email: cleanEmail,
        password: cleanPassword,
        options: {
          data: {
            full_name: fullName,
            username: cleanUsername,
            wallet_id: generatedWalletId,
            pin: cleanPin,
            referral_code: userRefCode,
            referred_by: cleanReferral,
            country: countryName,
            country_code: countryCode,
            preferred_currency: preferredCurrency
          }
        }
      });

      if (authError) {
        if (authError.message.includes("already registered") || authError.message.includes("User already registered")) {
          throw new Error("This email is already registered. Please login instead.");
        }
        throw new Error(authError.message || "Registration failed.");
      }

      const user = authData.user;
      if (!user) {
        throw new Error(
          "Account created but email confirmation may be required. Check your inbox or disable email confirmation in Supabase Auth settings."
        );
      }

      localStorage.setItem(`astc_pin_${user.id}`, cleanPin);

      // Hash PIN into profiles.pin_hash (transfer PIN = signup PIN)
      try {
        if (authData.session) {
          await client.rpc("set_my_pin", { p_pin: cleanPin });
        }
      } catch (e) {
        console.warn("Could not hash PIN at signup:", e);
      }

      const cachedProfile = {
        id: user.id,
        full_name: fullName,
        username: cleanUsername,
        email: cleanEmail,
        pin: cleanPin,
        referral_code: userRefCode,
        referred_by: cleanReferral,
        country: countryName,
        country_code: countryCode,
        preferred_currency: preferredCurrency,
        wallets: { wallet_id: generatedWalletId, balance: 0.0 }
      };

      localStorage.setItem("astc_active_user", JSON.stringify(cachedProfile));
      localStorage.setItem("astc_user_cache", JSON.stringify(cachedProfile));

      // 2. Try to insert into public tables (RLS must allow it)
      try {
        await client.from("profiles").upsert(
          {
            id: user.id,
            full_name: fullName,
            username: cleanUsername,
            email: cleanEmail,
            referral_code: userRefCode,
            referred_by: cleanReferral || null,
            country: countryName || null,
            country_code: countryCode || "NG",
            preferred_currency: preferredCurrency || "NGN"
          },
          { onConflict: "id" }
        );

        await client.from("wallets").upsert(
          {
            user_id: user.id,
            wallet_id: generatedWalletId,
            balance: 0.0
          },
          { onConflict: "user_id" }
        );
      } catch (dbErr) {
        console.warn("DB profile/wallet sync warning (check RLS policies):", dbErr);
      }

      return { success: true, user: cachedProfile };
    },

    /**
     * SIGN IN
     */
    async signIn(email, password) {
      const cleanEmail = (email || "").trim().toLowerCase();
      if (!cleanEmail || !password) {
        throw new Error("Email and password are required.");
      }

      const client = getClient();

      const { data, error } = await client.auth.signInWithPassword({
        email: cleanEmail,
        password: password
      });

      if (error) {
        if (error.message.includes("Invalid login credentials")) {
          throw new Error("Invalid email or password.");
        }
        if (error.message.includes("Email not confirmed")) {
          throw new Error("Please confirm your email first, or disable email confirmation in Supabase Auth settings.");
        }
        throw new Error(error.message || "Login failed.");
      }

      const user = data.user;
      if (!user) throw new Error("Login failed. No user returned.");

      const meta = user.user_metadata || {};

      // Try to load full profile + wallet from DB
      let dbProfile = null;
      try {
        const { data: profile, error: pErr } = await client
          .from("profiles")
          .select("*, wallets(*)")
          .eq("id", user.id)
          .maybeSingle();
        if (!pErr && profile) dbProfile = profile;
      } catch (e) {
        console.warn("Profile fetch warning:", e);
      }

      const walletFromDb = dbProfile?.wallets
        ? Array.isArray(dbProfile.wallets)
          ? dbProfile.wallets[0]
          : dbProfile.wallets
        : null;

      const resolvedProfile = {
        id: user.id,
        full_name: dbProfile?.full_name || meta.full_name || cleanEmail.split("@")[0],
        username: dbProfile?.username || meta.username || "",
        email: user.email,
        pin: meta.pin || localStorage.getItem(`astc_pin_${user.id}`) || "",
        referral_code: dbProfile?.referral_code || meta.referral_code || "",
        wallets: walletFromDb || {
          wallet_id: meta.wallet_id || `ASTC-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000 + Math.random() * 9000)}`,
          balance: 0.0
        }
      };

      localStorage.setItem("astc_active_user", JSON.stringify(resolvedProfile));
      localStorage.setItem("astc_user_cache", JSON.stringify(resolvedProfile));

      // If user set PIN at signup but pin_hash missing, save it once
      try {
        const pinTry = resolvedProfile.pin || localStorage.getItem(`astc_pin_${user.id}`);
        if (pinTry && /^\d{4}$/.test(pinTry)) {
          const { data: prof } = await client.from("profiles").select("pin_hash").eq("id", user.id).maybeSingle();
          if (!prof || !prof.pin_hash) {
            await client.rpc("set_my_pin", { p_pin: pinTry });
          }
        }
      } catch (e) {
        console.warn("PIN migrate on login:", e);
      }

      return { success: true, user: resolvedProfile };
    },

    /**
     * GET CURRENT USER (session + cache)
     */
    async getCurrentUser() {
      try {
        const local = localStorage.getItem("astc_active_user");
        let cachedUser = local ? JSON.parse(local) : null;

        const client = getClient();
        const { data: { session } } = await client.auth.getSession();

        if (session && session.user) {
          const user = session.user;
          const meta = user.user_metadata || {};

          let dbProfile = null;
          try {
            const { data: profile } = await client
              .from("profiles")
              .select("*, wallets(*)")
              .eq("id", user.id)
              .maybeSingle();
            if (profile) dbProfile = profile;
          } catch (e) {}

          const walletFromDb = dbProfile?.wallets
            ? Array.isArray(dbProfile.wallets)
              ? dbProfile.wallets[0]
              : dbProfile.wallets
            : null;

          cachedUser = {
            id: user.id,
            full_name: dbProfile?.full_name || meta.full_name || cachedUser?.full_name || user.email.split("@")[0],
            username: dbProfile?.username || meta.username || cachedUser?.username || "",
            email: user.email,
            pin: meta.pin || localStorage.getItem(`astc_pin_${user.id}`) || cachedUser?.pin || "",
            referral_code: dbProfile?.referral_code || meta.referral_code || cachedUser?.referral_code || "",
            wallets: walletFromDb || {
              wallet_id: meta.wallet_id || cachedUser?.wallets?.wallet_id || "ASTC-GENERATING",
              balance: cachedUser?.wallets?.balance || 0.0
            }
          };

          localStorage.setItem("astc_active_user", JSON.stringify(cachedUser));
          localStorage.setItem("astc_user_cache", JSON.stringify(cachedUser));
        }

        return cachedUser;
      } catch (err) {
        console.error("User Sync Error:", err);
        const local = localStorage.getItem("astc_active_user");
        return local ? JSON.parse(local) : null;
      }
    },

    /**
     * FORGOT PASSWORD - Send reset email
     */
    async resetPassword(email) {
      const cleanEmail = (email || "").trim().toLowerCase();
      if (!cleanEmail) {
        throw new Error("Please enter your email address.");
      }

      const client = getClient();

      // redirectTo must be a page that can handle the recovery token
      // Change this URL to your real domain when you deploy
      const redirectTo = window.location.origin + "/reset-password.html";

      const { error } = await client.auth.resetPasswordForEmail(cleanEmail, {
        redirectTo: redirectTo
      });

      if (error) {
        throw new Error(error.message || "Failed to send reset email.");
      }

      return { success: true };
    },

    /**
     * UPDATE PASSWORD (after user clicks the email link)
     */
    async updatePassword(newPassword) {
      if (!newPassword || newPassword.length < 6) {
        throw new Error("Password must be at least 6 characters.");
      }

      const client = getClient();

      const { data, error } = await client.auth.updateUser({
        password: newPassword
      });

      if (error) {
        throw new Error(error.message || "Failed to update password. The reset link may have expired.");
      }

      return { success: true, user: data.user };
    },

    /**
     * LOG OUT
     */
    async signOut() {
      try {
        const client = getClient();
        await client.auth.signOut();
      } catch (e) {}
      localStorage.removeItem("astc_active_user");
      localStorage.removeItem("astc_user_cache");
      window.location.href = "login.html";
    }
  };

  window.ASTC_AUTH = ASTC_AUTH;
})();
