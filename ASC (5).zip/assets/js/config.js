/**
 * ASOLITECOIN (ASTC) - Supabase Configuration
 */

const SUPABASE_URL = "https://tmtvgsmzxgekqlkartsg.supabase.co";

// Your real anon / public key
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRtdHZnc216eGdla3Fsa2FydHNnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk2MjM3MTYsImV4cCI6MjEwNTE5OTcxNn0.C_AKbKQHmIPcjUVnON96us97CBCvtLEBCZbWkoWf5M0";

// Make them available globally
window.SUPABASE_URL = SUPABASE_URL;
window.SUPABASE_ANON_KEY = SUPABASE_ANON_KEY;
