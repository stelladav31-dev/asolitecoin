/* ==========================================================================
   ASOLITECOIN (ASTC) - PLATFORM FEATURE FLAGS & SYSTEM RULES SERVICE
   ========================================================================== */

const ASTC_FEATURES = {
  // Local cached settings
  _settings: null,

  /**
   * Fetches latest platform settings and feature flags from Supabase
   * @returns {Promise<Object>}
   */
  async loadSettings() {
    if (!supabaseClient) return null;

    try {
      const { data, error } = await supabaseClient
        .from("platform_settings")
        .select("*")
        .eq("id", 1)
        .single();

      if (error) {
        console.error("Failed to load platform settings:", error.message);
        return this.getFallbackSettings();
      }

      this._settings = data;
      return data;
    } catch (err) {
      console.error("Error loading settings:", err);
      return this.getFallbackSettings();
    }
  },

  /**
   * Checks whether a specific feature module is currently enabled by Admin
   * @param {string} featureKey - e.g., 'buy', 'sell', 'earn', 'predict', 'refer', 'aixtrade', 'calculate', 'convert', 'check_balance', 'support'
   * @returns {Promise<boolean>}
   */
  async isFeatureEnabled(featureKey) {
    if (!this._settings) {
      await this.loadSettings();
    }
    
    if (this._settings && this._settings.feature_flags) {
      return !!this._settings.feature_flags[featureKey];
    }
    return true; // Default fallback open
  },

  /**
   * Gets current official ASTC price in NGN
   * @returns {Promise<number>}
   */
  async getCurrentPrice() {
    if (!this._settings) {
      await this.loadSettings();
    }
    return this._settings ? parseFloat(this._settings.current_astc_price_ngn) : 26700.00;
  },

  /**
   * Safe fallback parameters if network or DB connection is delayed
   */
  getFallbackSettings() {
    return {
      id: 1,
      current_astc_price_ngn: 26700.00,
      previous_astc_price_ngn: 26700.00,
      feature_flags: {
        buy: true,
        sell: true,
        earn: true,
        predict: true,
        refer: true,
        aixtrade: true,
        calculate: true,
        convert: true,
        check_balance: true,
        support: true
      }
    };
  },

  /**
   * Intercepts feature navigation and displays a notice if the requested feature is disabled
   * @param {string} featureKey 
   * @param {Function} callback 
   */
  async guardFeature(featureKey, callback) {
    const enabled = await this.isFeatureEnabled(featureKey);
    if (!enabled) {
      alert(`The ${featureKey.toUpperCase()} service is currently under scheduled maintenance. Please check back shortly.`);
      return;
    }
    if (typeof callback === "function") {
      callback();
    }
  }
};
