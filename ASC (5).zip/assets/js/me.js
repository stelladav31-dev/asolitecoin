/**
 * ASOLITECOIN - ME / Profile Controller
 */
(function () {
  function getClient() {
    if (window._astcSupabaseClient) return window._astcSupabaseClient;
    const url = window.SUPABASE_URL;
    const key = window.SUPABASE_ANON_KEY;
    if (!url || !key || !window.supabase) throw new Error("Supabase not ready");
    window._astcSupabaseClient = window.supabase.createClient(url, key);
    return window._astcSupabaseClient;
  }

  const ASTC_ME = {
    async getProfile() {
      if (window.ASTC_AUTH && ASTC_AUTH.getCurrentUser) {
        return await ASTC_AUTH.getCurrentUser();
      }
      return null;
    },

    async refreshProfile() {
      const client = getClient();
      const { data: { user } } = await client.auth.getUser();
      if (!user) return null;

      const { data: profile } = await client
        .from("profiles")
        .select("*, wallets(*)")
        .eq("id", user.id)
        .maybeSingle();

      if (!profile) return null;

      const wallet = Array.isArray(profile.wallets)
        ? profile.wallets[0]
        : profile.wallets;

      const resolved = {
        id: user.id,
        full_name: profile.full_name,
        username: profile.username,
        email: user.email || profile.email,
        avatar_url: profile.avatar_url || null,
        country: profile.country || "",
        country_code: profile.country_code || "NG",
        preferred_currency: profile.preferred_currency || "NGN",
        account_status: profile.account_status || "active",
        is_verified: !!profile.is_verified,
        is_admin: !!profile.is_admin,
        is_vendor: !!profile.is_vendor,
        lookup_key: profile.lookup_key,
        balance_lookup_enabled: !!profile.balance_lookup_enabled,
        referral_code: profile.referral_code,
        role: profile.role || "user",
        created_at: profile.created_at,
        has_pin: !!(profile.pin_hash),
        wallets: wallet || { wallet_id: "—", balance: 0 }
      };

      localStorage.setItem("astc_active_user", JSON.stringify(resolved));
      localStorage.setItem("astc_user_cache", JSON.stringify(resolved));
      return resolved;
    },

    async updateName(fullName) {
      const name = (fullName || "").trim();
      if (name.length < 2) throw new Error("Name must be at least 2 characters.");
      const client = getClient();
      const { data: { user } } = await client.auth.getUser();
      if (!user) throw new Error("Not logged in.");

      const { error } = await client
        .from("profiles")
        .update({ full_name: name })
        .eq("id", user.id);
      if (error) throw new Error(error.message);

      await client.auth.updateUser({ data: { full_name: name } });
      return this.refreshProfile();
    },

    async updateUsername(username) {
      const u = (username || "").trim().toLowerCase().replace(/[^a-z0-9_]/g, "");
      if (u.length < 3) throw new Error("Username must be at least 3 characters (letters, numbers, _).");
      const client = getClient();
      const { data: { user } } = await client.auth.getUser();
      if (!user) throw new Error("Not logged in.");

      // Check uniqueness
      const { data: existing } = await client
        .from("profiles")
        .select("id")
        .eq("username", u)
        .neq("id", user.id)
        .maybeSingle();

      if (existing) throw new Error("Username already taken. Please choose another.");

      const { error } = await client
        .from("profiles")
        .update({ username: u })
        .eq("id", user.id);
      if (error) {
        if (error.code === "23505" || (error.message || "").includes("unique")) {
          throw new Error("Username already taken. Please choose another.");
        }
        throw new Error(error.message);
      }

      await client.auth.updateUser({ data: { username: u } });
      return this.refreshProfile();
    },

    async setBalanceLookup(enabled) {
      const client = getClient();
      const { data: { user } } = await client.auth.getUser();
      if (!user) throw new Error("Not logged in.");

      const { error } = await client
        .from("profiles")
        .update({ balance_lookup_enabled: !!enabled })
        .eq("id", user.id);
      if (error) throw new Error(error.message);
      return this.refreshProfile();
    },

    async changeLookupKey() {
      const client = getClient();
      const { data, error } = await client.rpc("change_my_lookup_key");
      if (error) throw new Error(error.message);
      if (!data || !data.ok) throw new Error((data && data.error) || "Failed to change key.");
      const profile = await this.refreshProfile();
      return { profile, lookup_key: data.lookup_key };
    },

    async uploadAvatar(file) {
      if (!file || !file.type.startsWith("image/")) {
        throw new Error("Please select a valid image file.");
      }
      if (file.size > 2 * 1024 * 1024) {
        throw new Error("Image must be under 2 MB.");
      }

      const client = getClient();
      const { data: { user } } = await client.auth.getUser();
      if (!user) throw new Error("Not logged in.");

      const ext = (file.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "");
      const path = `${user.id}/avatar.${ext === "jpeg" ? "jpg" : ext}`;

      const { error: upErr } = await client.storage
        .from("avatars")
        .upload(path, file, { upsert: true, contentType: file.type });
      if (upErr) throw new Error(upErr.message || "Upload failed.");

      const { data: pub } = client.storage.from("avatars").getPublicUrl(path);
      const avatarUrl = pub.publicUrl + "?t=" + Date.now();

      const { error } = await client
        .from("profiles")
        .update({ avatar_url: avatarUrl })
        .eq("id", user.id);
      if (error) throw new Error(error.message);

      return this.refreshProfile();
    },

    async removeAvatar() {
      const client = getClient();
      const { data: { user } } = await client.auth.getUser();
      if (!user) throw new Error("Not logged in.");

      // Best-effort delete of common paths
      try {
        const { data: files } = await client.storage.from("avatars").list(user.id);
        if (files && files.length) {
          await client.storage.from("avatars").remove(files.map((f) => `${user.id}/${f.name}`));
        }
      } catch (e) {}

      const { error } = await client
        .from("profiles")
        .update({ avatar_url: null })
        .eq("id", user.id);
      if (error) throw new Error(error.message);
      return this.refreshProfile();
    },

    async changePassword(currentPassword, newPassword) {
      if (!newPassword || newPassword.length < 6) {
        throw new Error("New password must be at least 6 characters.");
      }
      const client = getClient();
      const { data: { user } } = await client.auth.getUser();
      if (!user || !user.email) throw new Error("Not logged in.");

      // Re-auth with current password
      const { error: signErr } = await client.auth.signInWithPassword({
        email: user.email,
        password: currentPassword
      });
      if (signErr) throw new Error("Current password is incorrect.");

      const { error } = await client.auth.updateUser({ password: newPassword });
      if (error) throw new Error(error.message);
      return true;
    },

    async setPin(pin) {
      if (!/^\d{4}$/.test(pin)) throw new Error("PIN must be exactly 4 digits.");
      const client = getClient();
      const { data, error } = await client.rpc("set_my_pin", { p_pin: pin });
      if (error) throw new Error(error.message);
      if (!data || !data.ok) throw new Error((data && data.error) || "Failed to set PIN.");
      return this.refreshProfile();
    },

    async changePin(oldPin, newPin) {
      if (!/^\d{4}$/.test(newPin)) throw new Error("New PIN must be exactly 4 digits.");
      const client = getClient();
      const { data, error } = await client.rpc("change_my_pin", { p_old: oldPin, p_new: newPin });
      if (error) throw new Error(error.message);
      if (!data || !data.ok) throw new Error((data && data.error) || "Failed to change PIN.");
      return this.refreshProfile();
    },

    async getTransactions(limit = 50, searchWallet = "") {
      const client = getClient();
      const { data: { user } } = await client.auth.getUser();
      if (!user) return [];

      let q = client
        .from("transactions")
        .select("*")
        .or(`sender_user_id.eq.${user.id},recipient_user_id.eq.${user.id}`)
        .order("created_at", { ascending: false })
        .limit(limit);

      const { data, error } = await q;
      if (error) {
        console.warn(error);
        return [];
      }

      let rows = data || [];
      if (searchWallet) {
        const s = searchWallet.trim().toLowerCase();
        rows = rows.filter(
          (t) =>
            (t.sender_wallet_id || "").toLowerCase().includes(s) ||
            (t.recipient_wallet_id || "").toLowerCase().includes(s)
        );
      }
      return rows;
    },

    async getReferrals() {
      const client = getClient();
      const { data: { user } } = await client.auth.getUser();
      if (!user) return [];
      const { data } = await client
        .from("referrals")
        .select("*")
        .eq("referrer_user_id", user.id)
        .order("created_at", { ascending: false });
      return data || [];
    },

    async submitSupport({ subject, category, message }) {
      const client = getClient();
      const profile = await this.refreshProfile();
      if (!profile) throw new Error("Not logged in.");

      const { error } = await client.from("support_tickets").insert({
        user_id: profile.id,
        full_name: profile.full_name,
        email: profile.email,
        wallet_id: profile.wallets?.wallet_id || null,
        subject: (subject || "").trim(),
        category: category || "general",
        message: (message || "").trim()
      });
      if (error) throw new Error(error.message);
      return true;
    },

    async getSupportTickets() {
      const client = getClient();
      const { data: { user } } = await client.auth.getUser();
      if (!user) return [];
      const { data } = await client
        .from("support_tickets")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });
      return data || [];
    },

    async getNotifications() {
      const client = getClient();
      const { data: { user } } = await client.auth.getUser();
      if (!user) return [];
      const { data } = await client
        .from("notifications")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(50);
      return data || [];
    },

    async markNotificationRead(id) {
      const client = getClient();
      await client.from("notifications").update({ is_read: true }).eq("id", id);
    },

    async lookupBalance(key) {
      const client = getClient();
      const { data, error } = await client.rpc("lookup_balance_by_key", { p_key: key });
      if (error) throw new Error(error.message);
      return data;
    }
  };

  window.ASTC_ME = ASTC_ME;
})();
