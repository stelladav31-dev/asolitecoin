/* ==========================================================================
   ASOLITECOIN (ASTC) - TRANSACTION LEDGER & REAL-TIME WEBSOCKET ENGINE
   ========================================================================== */

const ASTC_TRANSACTIONS = {
  // Real-time channel reference
  _subscription: null,

  /**
   * Fetches the current user's ASTC wallet balance
   * @param {string} userId 
   * @returns {Promise<number>}
   */
  async getWalletBalance(userId) {
    if (!supabaseClient) return 0.04000000;

    const { data, error } = await supabaseClient
      .from("wallets")
      .select("balance, wallet_id")
      .eq("user_id", userId)
      .single();

    if (error) {
      console.error("Error loading wallet balance:", error.message);
      return 0.04000000;
    }

    return parseFloat(data.balance);
  },

  /**
   * Executes an atomic ASTC transfer via RPC stored procedure
   * @param {Object} params
   * @param {string} params.senderId
   * @param {string} params.recipientWalletId
   * @param {number} params.amount
   * @param {string} params.pin - Raw 4-digit PIN (will be hashed)
   * @returns {Promise<Object>}
   */
  async sendASTC({ senderId, recipientWalletId, amount, pin }) {
    if (!ASTC_PIN.validateFormat(pin)) {
      throw new Error("PIN must be exactly 4 numeric digits.");
    }

    const pinHash = await ASTC_PIN.hashPin(pin);

    // Call atomic SQL RPC procedure
    const { data, error } = await supabaseClient.rpc("execute_transfer", {
      p_sender_id: senderId,
      p_recipient_wallet_id: recipientWalletId.trim().toUpperCase(),
      p_amount: parseFloat(amount),
      p_pin_hash: pinHash
    });

    if (error) {
      console.error("RPC Transfer error:", error.message);
      throw new Error(error.message.replace("error: ", ""));
    }

    return data;
  },

  /**
   * Retrieves transaction history for a user's wallet
   * @param {string} walletId 
   * @param {number} limit 
   * @returns {Promise<Array>}
   */
  async getHistory(walletId, limit = 20) {
    if (!supabaseClient || !walletId) return [];

    const { data, error } = await supabaseClient
      .from("transactions")
      .select("*")
      .or(`sender_wallet_id.eq.${walletId},recipient_wallet_id.eq.${walletId}`)
      .order("created_at", { ascending: false })
      .limit(limit);

    if (error) {
      console.error("Error fetching transaction history:", error.message);
      return [];
    }

    return data || [];
  },

  /**
   * Subscribes to real-time wallet balance changes via Supabase WebSockets
   * @param {string} userId 
   * @param {Function} onBalanceUpdate Callback triggered when balance changes
   */
  subscribeToBalanceChanges(userId, onBalanceUpdate) {
    if (!supabaseClient || !userId) return;

    if (this._subscription) {
      this._subscription.unsubscribe();
    }

    this._subscription = supabaseClient
      .channel(`wallet_changes_${userId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "wallets",
          filter: `user_id=eq.${userId}`
        },
        (payload) => {
          if (payload.new && typeof onBalanceUpdate === "function") {
            onBalanceUpdate(parseFloat(payload.new.balance));
          }
        }
      )
      .subscribe();
  },

  /**
   * Unsubscribes from current real-time channel
   */
  unsubscribe() {
    if (this._subscription) {
      this._subscription.unsubscribe();
      this._subscription = null;
    }
  }
};
