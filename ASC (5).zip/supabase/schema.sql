-- ============================================================================
-- ASOLITECOIN (ASTC) - MASTER DATABASE SCHEMA
-- ============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ----------------------------------------------------------------------------
-- 1. ENUMS & CONSTANTS
-- ----------------------------------------------------------------------------
CREATE TYPE user_role AS ENUM ('admin', 'user', 'verified_member');
CREATE TYPE account_status AS ENUM ('active', 'frozen', 'suspended');
CREATE TYPE transaction_type AS ENUM ('transfer', 'issuance', 'referral_reward', 'prediction_reward', 'fee');
CREATE TYPE transaction_status AS ENUM ('successful', 'pending', 'failed');
CREATE TYPE ticket_status AS ENUM ('open', 'in_progress', 'resolved', 'closed');

-- ----------------------------------------------------------------------------
-- 2. USER PROFILES TABLE
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name VARCHAR(120) NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    country VARCHAR(100) NOT NULL,
    currency_code VARCHAR(10) NOT NULL DEFAULT 'NGN',
    profile_picture TEXT DEFAULT NULL,
    role user_role NOT NULL DEFAULT 'user',
    account_status account_status NOT NULL DEFAULT 'active',
    email_verified BOOLEAN NOT NULL DEFAULT FALSE,
    pin_hash VARCHAR(255) DEFAULT NULL, -- Hashed 4-digit PIN
    referral_code VARCHAR(20) UNIQUE NOT NULL,
    referred_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_activity TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 3. ASTC WALLETS TABLE
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.wallets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID UNIQUE NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    wallet_id VARCHAR(30) UNIQUE NOT NULL, -- e.g. ASTC48291XYZ
    balance NUMERIC(20,8) NOT NULL DEFAULT 0.00000000 CHECK (balance >= 0.00000000),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 4. TRANSACTIONS LEDGER TABLE
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    transaction_id VARCHAR(50) UNIQUE NOT NULL,
    sender_wallet_id VARCHAR(30) REFERENCES public.wallets(wallet_id),
    recipient_wallet_id VARCHAR(30) REFERENCES public.wallets(wallet_id),
    amount NUMERIC(20,8) NOT NULL CHECK (amount > 0),
    fee NUMERIC(20,8) NOT NULL DEFAULT 0.00000000 CHECK (fee >= 0),
    transaction_type transaction_type NOT NULL,
    status transaction_status NOT NULL DEFAULT 'successful',
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 5. VERIFIED MEMBERS MARKETPLACE TABLE
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.verified_members (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID UNIQUE NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    display_name VARCHAR(120) NOT NULL,
    country VARCHAR(100) NOT NULL,
    selling_price NUMERIC(20,2) NOT NULL DEFAULT 0.00,
    currency_code VARCHAR(10) NOT NULL DEFAULT 'NGN',
    whatsapp_number VARCHAR(30) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 6. PLATFORM SETTINGS & FEATURE FLAGS TABLE
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.platform_settings (
    id INT PRIMARY KEY DEFAULT 1 CHECK (id = 1), -- Single row configuration pattern
    platform_fee_wallet_id VARCHAR(30) REFERENCES public.wallets(wallet_id),
    current_astc_price_ngn NUMERIC(20,2) NOT NULL DEFAULT 26700.00,
    previous_astc_price_ngn NUMERIC(20,2) NOT NULL DEFAULT 26700.00,
    price_last_updated TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    feature_flags JSONB NOT NULL DEFAULT '{
        "buy": true,
        "sell": true,
        "earn": true,
        "predict": true,
        "refer": true,
        "aixtrade": true,
        "calculate": true,
        "convert": true,
        "check_balance": true,
        "support": true
    }'::jsonb,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 7. ACCOUNT VIEW KEYS TABLE (CHECK ACCOUNT BALANCE)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.account_view_keys (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID UNIQUE NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    view_key_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 8. SUPPORT TICKETS TABLE
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.support_tickets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ticket_id VARCHAR(20) UNIQUE NOT NULL,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    subject VARCHAR(200) NOT NULL,
    complaint TEXT NOT NULL,
    status ticket_status NOT NULL DEFAULT 'open',
    admin_response TEXT DEFAULT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 9. AUDIT LOGS TABLE
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    admin_id UUID NOT NULL REFERENCES public.profiles(id),
    action VARCHAR(100) NOT NULL,
    target_id VARCHAR(100) DEFAULT NULL,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 10. INDEXES FOR HIGH-PERFORMANCE SEARCH & QUERYING
-- ----------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_profiles_username ON public.profiles(username);
CREATE INDEX IF NOT EXISTS idx_profiles_email ON public.profiles(email);
CREATE INDEX IF NOT EXISTS idx_profiles_referral ON public.profiles(referral_code);
CREATE INDEX IF NOT EXISTS idx_wallets_wallet_id ON public.wallets(wallet_id);
CREATE INDEX IF NOT EXISTS idx_transactions_sender ON public.transactions(sender_wallet_id);
CREATE INDEX IF NOT EXISTS idx_transactions_recipient ON public.transactions(recipient_wallet_id);
CREATE INDEX IF NOT EXISTS idx_transactions_type ON public.transactions(transaction_type);
