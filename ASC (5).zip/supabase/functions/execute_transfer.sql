-- ============================================================================
-- ASOLITECOIN (ASTC) - ATOMIC ASTC TRANSFER ENGINE
-- ============================================================================

CREATE OR REPLACE FUNCTION public.execute_transfer(
    p_sender_id UUID,
    p_recipient_wallet_id VARCHAR,
    p_amount NUMERIC,
    p_pin_hash VARCHAR
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_sender_profile RECORD;
    v_sender_wallet RECORD;
    v_recipient_wallet RECORD;
    v_platform_fee_wallet_id VARCHAR;
    v_fee NUMERIC(20,8);
    v_total_deduction NUMERIC(20,8);
    v_remaining_balance NUMERIC(20,8);
    v_tx_id VARCHAR(50);
    v_min_balance CONSTANT NUMERIC(20,8) := 0.04000000;
    v_fee_ratio CONSTANT NUMERIC(20,8) := 0.00100000; -- 0.1% proportional fee
BEGIN
    -- 1. Validate Input Parameters
    IF p_amount IS NULL OR p_amount <= 0 THEN
        RAISE EXCEPTION 'Transfer amount must be greater than 0.';
    END IF;

    -- 2. Fetch and Validate Sender Profile & Status
    SELECT * INTO v_sender_profile
    FROM public.profiles
    WHERE id = p_sender_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Sender account profile not found.';
    END IF;

    IF v_sender_profile.account_status != 'active' THEN
        RAISE EXCEPTION 'Sender account is % and cannot perform transfers.', v_sender_profile.account_status;
    END IF;

    -- 3. Verify Transaction PIN Hash
    IF v_sender_profile.pin_hash IS NULL THEN
        RAISE EXCEPTION 'Transaction PIN is not configured on your account.';
    END IF;

    IF v_sender_profile.pin_hash != p_pin_hash THEN
        RAISE EXCEPTION 'Invalid transaction PIN provided.';
    END IF;

    -- 4. Fetch Sender Wallet
    SELECT * INTO v_sender_wallet
    FROM public.wallets
    WHERE user_id = p_sender_id
    FOR UPDATE; -- Row-level lock to prevent race conditions

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Sender wallet record missing.';
    END IF;

    -- 5. Fetch Recipient Wallet
    SELECT * INTO v_recipient_wallet
    FROM public.wallets
    WHERE wallet_id = p_recipient_wallet_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Recipient wallet address % does not exist.', p_recipient_wallet_id;
    END IF;

    IF v_sender_wallet.wallet_id = v_recipient_wallet.wallet_id THEN
        RAISE EXCEPTION 'Cannot transfer ASTC to your own wallet address.';
    END IF;

    -- 6. Calculate Fee and Minimum Balance Reserve Rules
    -- Fee formula: amount * 0.001 (0.1%)
    v_fee := ROUND((p_amount * v_fee_ratio), 8);
    v_total_deduction := p_amount + v_fee;
    v_remaining_balance := v_sender_wallet.balance - v_total_deduction;

    -- ENFORCE MINIMUM BALANCE REQUIREMENT: Remaining balance MUST be >= 0.04 ASTC
    IF v_remaining_balance < v_min_balance THEN
        RAISE EXCEPTION 'Transfer rejected. Account must retain a minimum balance of 0.04 ASTC. Maximum sendable considering fee is exceeded.';
    END IF;

    -- 7. Fetch Configured Platform Fee Wallet
    SELECT platform_fee_wallet_id INTO v_platform_fee_wallet_id
    FROM public.platform_settings
    WHERE id = 1;

    IF v_platform_fee_wallet_id IS NULL OR v_platform_fee_wallet_id = '' THEN
        RAISE EXCEPTION 'System setup error: Platform fee wallet is not configured by Admin.';
    END IF;

    -- 8. Generate Unique Transaction Identifier
    v_tx_id := 'TX' || UPPER(SUBSTRING(MD5(RANDOM()::TEXT || NOW()::TEXT) FROM 1 FOR 12));

    -- 9. Perform Atomic Balance Adjustments
    -- Debit Sender
    UPDATE public.wallets
    SET balance = balance - v_total_deduction,
        updated_at = NOW()
    WHERE id = v_sender_wallet.id;

    -- Credit Recipient
    UPDATE public.wallets
    SET balance = balance + p_amount,
        updated_at = NOW()
    WHERE id = v_recipient_wallet.id;

    -- Credit Platform Fee Wallet (if fee > 0)
    IF v_fee > 0 THEN
        UPDATE public.wallets
        SET balance = balance + v_fee,
            updated_at = NOW()
        WHERE wallet_id = v_platform_fee_wallet_id;
    END IF;

    -- 10. Record Ledger Entry
    INSERT INTO public.transactions (
        transaction_id,
        sender_wallet_id,
        recipient_wallet_id,
        amount,
        fee,
        transaction_type,
        status,
        metadata
    ) VALUES (
        v_tx_id,
        v_sender_wallet.wallet_id,
        v_recipient_wallet.wallet_id,
        p_amount,
        v_fee,
        'transfer',
        'successful',
        jsonb_build_object(
            'fee_wallet_credited', v_platform_fee_wallet_id,
            'timestamp', NOW()
        )
    );

    -- 11. Return Transaction Result
    RETURN jsonb_build_object(
        'success', true,
        'transaction_id', v_tx_id,
        'amount_sent', p_amount,
        'fee_charged', v_fee,
        'total_deducted', v_total_deduction,
        'remaining_balance', v_remaining_balance,
        'recipient_wallet', v_recipient_wallet.wallet_id
    );

EXCEPTION WHEN OTHERS THEN
    -- Rollback occurs automatically on exception
    RAISE EXCEPTION 'Transfer failed: %', SQLERRM;
END;
$$;
