-- ============================================================================
-- ASOLITECOIN (ASTC) - ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. ENABLE RLS ON ALL TABLES
-- ----------------------------------------------------------------------------
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wallets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.verified_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.platform_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.account_view_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.support_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- Helper Function: Check if authenticated user is an Admin
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin' AND account_status = 'active'
  );
$$;

-- ----------------------------------------------------------------------------
-- 2. PROFILES POLICIES
-- ----------------------------------------------------------------------------
-- Users can read their own profile
CREATE POLICY "Users can read own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id);

-- Users can update non-sensitive fields on their own profile
CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

-- Admins can read all profiles
CREATE POLICY "Admins can read all profiles"
  ON public.profiles FOR SELECT
  USING (public.is_admin());

-- Admins can update all profiles (for status/role changes)
CREATE POLICY "Admins can update all profiles"
  ON public.profiles FOR UPDATE
  USING (public.is_admin());

-- ----------------------------------------------------------------------------
-- 3. WALLETS POLICIES
-- ----------------------------------------------------------------------------
-- Users can read their own wallet
CREATE POLICY "Users can read own wallet"
  ON public.wallets FOR SELECT
  USING (auth.uid() = user_id);

-- Admins can view all wallets
CREATE POLICY "Admins can view all wallets"
  ON public.wallets FOR SELECT
  USING (public.is_admin());

-- Note: DIRECT BALANCE UPDATE IS FORBIDDEN FOR ALL USERS.
-- Balances must ONLY be modified via backend RPC stored procedures (SECURITY DEFINER).

-- ----------------------------------------------------------------------------
-- 4. TRANSACTIONS POLICIES
-- ----------------------------------------------------------------------------
-- Users can view transactions where they are sender or recipient
CREATE POLICY "Users can view own transactions"
  ON public.transactions FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.wallets
      WHERE user_id = auth.uid()
      AND (wallet_id = transactions.sender_wallet_id OR wallet_id = transactions.recipient_wallet_id)
    )
  );

-- Admins can view all platform transactions
CREATE POLICY "Admins can view all transactions"
  ON public.transactions FOR SELECT
  USING (public.is_admin());

-- ----------------------------------------------------------------------------
-- 5. VERIFIED MEMBERS (BUY/SELL MARKETPLACE) POLICIES
-- ----------------------------------------------------------------------------
-- Anyone authenticated can view active verified members
CREATE POLICY "Anyone can view active verified members"
  ON public.verified_members FOR SELECT
  USING (is_active = true);

-- Admins can manage all verified member records
CREATE POLICY "Admins can manage verified members"
  ON public.verified_members FOR ALL
  USING (public.is_admin());

-- ----------------------------------------------------------------------------
-- 6. PLATFORM SETTINGS POLICIES
-- ----------------------------------------------------------------------------
-- Anyone authenticated can read platform settings (for price & feature flags)
CREATE POLICY "Anyone can read platform settings"
  ON public.platform_settings FOR SELECT
  USING (true);

-- Only admins can update platform settings
CREATE POLICY "Admins can update platform settings"
  ON public.platform_settings FOR UPDATE
  USING (public.is_admin());

-- ----------------------------------------------------------------------------
-- 7. SUPPORT TICKETS POLICIES
-- ----------------------------------------------------------------------------
-- Users can view their own tickets
CREATE POLICY "Users can view own support tickets"
  ON public.support_tickets FOR SELECT
  USING (auth.uid() = user_id);

-- Users can create support tickets
CREATE POLICY "Users can create support tickets"
  ON public.support_tickets FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Admins can manage all support tickets
CREATE POLICY "Admins can manage all support tickets"
  ON public.support_tickets FOR ALL
  USING (public.is_admin());

-- ----------------------------------------------------------------------------
-- 8. AUDIT LOGS POLICIES
-- ----------------------------------------------------------------------------
-- Only admins can view audit logs
CREATE POLICY "Admins can view audit logs"
  ON public.audit_logs FOR SELECT
  USING (public.is_admin());
